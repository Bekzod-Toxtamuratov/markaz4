export class CreateRoleDto {
    name:string
}
