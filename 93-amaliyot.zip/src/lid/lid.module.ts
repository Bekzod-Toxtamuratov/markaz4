import { Module } from '@nestjs/common';
import { LidService } from './lid.service';
import { LidController } from './lid.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Lid } from './entities/lid.entity';
import { LidStatus } from 'src/lid_status/entities/lid_status.entity';
import { LidResolvers } from './lid.resolvers';

@Module({
  imports:[TypeOrmModule.forFeature([Lid, LidStatus])],
  // controllers: [LidController],
  providers: [LidService, LidResolvers],
})
export class LidModule {}
