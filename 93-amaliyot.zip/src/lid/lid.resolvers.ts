import { Controller, Get, Post, Body, Patch, Param, Delete, } from '@nestjs/common';
import { LidService } from './lid.service';
import { CreateLidDto } from './dto/create-lid.dto';
import { UpdateLidDto } from './dto/update-lid.dto';
import { Lid } from './entities/lid.entity';
import { Args, Mutation, Query } from '@nestjs/graphql';

@Controller('lid')
export class LidResolvers {
  constructor(private readonly lidService: LidService) {}

  @Mutation(() => Lid)
  createLId(
    @Args("createLidDto") createLidDto: CreateLidDto,
    @Args("id") id: number,
    @Args("target_id") target_id: number
  ) {
    
    console.log(createLidDto);
    
    return this.lidService.create(createLidDto, id, target_id);
  }

  @Query(()=>[Lid] )
  findAllLid() {
   
    return this.lidService.findAll();
  }

  // @Post()
  // create(@Body() CreateLidDto: CreateLidDto) {
  //   return this.lidService.create(createLidDto);
  // }

  // @Get()
  // findAll() {
  //   return this.lidService.findAll();
  // }

  // @Get(':id')
  // findOne(@Param('id') id: string) {
  //   return this.lidService.findOne(+id);
  // }

  // @Patch(':id')
  // update(@Param('id') id: string, @Body() updateLidDto: UpdateLidDto) {
  //   return this.lidService.update(+id, updateLidDto);
  // }

  // @Delete(':id')
  // remove(@Param('id') id: string) {
  //   return this.lidService.remove(+id);
  // }
}
