import { PartialType } from '@nestjs/mapped-types';
import { CreateLidDto } from './create-lid.dto';
import { Field, InputType } from '@nestjs/graphql';



@InputType()
export class UpdateLidDto extends PartialType(CreateLidDto) {
    @Field()
    first_name?:string

    @Field()
    last_name?:string

}
