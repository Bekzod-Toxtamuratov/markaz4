export class CreateLessonDto {
    lesson_theme:string
    lesson_number:number
    group_id:object
    lesson_date:Date
}
