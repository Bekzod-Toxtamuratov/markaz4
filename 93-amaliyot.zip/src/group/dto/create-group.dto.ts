export class CreateGroupDto {
    group_name:string
    lesson_start_time:string
    lesson_continuous:string
    lesson_week_day:string
    group_stage_id:object
    room_number:number
    room_floor:number
    branch_id:object
    lessons_quant:number
    is_active:boolean

}
