export class CreateReasonLidDto {
    reason_lid:string
}
