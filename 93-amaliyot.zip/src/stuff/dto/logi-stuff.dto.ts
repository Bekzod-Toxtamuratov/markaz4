export class LoginStuffDto {
    login:string
    parol:string   
}
