export class CreateStuffDto {
    first_name:string
    last_name:string
    phone_number:string
    login:string
    parol:string
    confirm_parol:string
    role:string
    
}
