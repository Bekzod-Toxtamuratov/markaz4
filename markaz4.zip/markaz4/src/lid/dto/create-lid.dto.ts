export class CreateLidDto {
    first_name:string
    last_name:string
    phone_number:string
    target_id:object
    lid_stage_id:object
    test_date:string
    trial_lesson_date:string
    trial_lesson_time:string
    trial_lesson_group_id:number
    lid_status_id:object
    reason_lid_id:object

}
