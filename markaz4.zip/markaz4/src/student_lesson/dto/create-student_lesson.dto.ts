export class CreateStudentLessonDto {
    lesson_id:object
    student_id:object
    is_there:boolean
    reason:string
    be_paid:boolean
}
