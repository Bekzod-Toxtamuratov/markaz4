export class CreateBranchDto {
    name:string
    address:string
    call_number:string
}
