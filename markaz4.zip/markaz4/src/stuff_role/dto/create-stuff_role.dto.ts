export class CreateStuffRoleDto {
    roleId:object
    stuffId:object
}
