export class CreateStudentDto {
    lid_id:object
    first_name:string
    last_name:string
    phone_number:string
    bith_date:string
    gender:string
}
