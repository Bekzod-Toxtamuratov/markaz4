export class CreateStudentGroupDto {
    student_id:object
    group_id:object
}
