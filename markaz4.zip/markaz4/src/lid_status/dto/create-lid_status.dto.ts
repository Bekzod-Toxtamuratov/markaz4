export class CreateLidStatusDto {
    status:string
}
