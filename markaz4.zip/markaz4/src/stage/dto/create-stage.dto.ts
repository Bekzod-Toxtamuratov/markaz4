export class CreateStageDto {
    name:string
}
