export class CreateGroupStuffDto {
    group_id:object
    stuff_id:object
}
